# pxtone-renderer
Render pxtone projects.

Requires C++17 and CMake. libogg/vorbis by xiph.org, pxtone by Studio Pixel, bugfixes by Clownacy
