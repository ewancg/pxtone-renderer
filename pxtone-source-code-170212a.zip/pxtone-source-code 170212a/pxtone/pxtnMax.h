﻿// '12/03/05

#define pxtnMAX_CHANNEL             2

#define pxtnMAX_TUNEUNITSTRUCT	   50 //    32
#define pxtnMAX_TUNEWOICESTRUCT	  100 //    32
#define pxtnMAX_EVENTNUM       500000 // 65536
#define pxtnMAX_TUNEGROUPNUM        7
#define pxtnMAX_TUNEDELAYSTRUCT     4
#define pxtnMAX_TUNEOVERDRIVESTRUCT 2
#define pxtnMAX_STREAMINGVOICE     10
#define pxtnMAX_RELEASEPOINT        1

#define CLOCK_ROUGH                10

#define pxtnMAX_TUNEUNITNAME       16 //fixture
